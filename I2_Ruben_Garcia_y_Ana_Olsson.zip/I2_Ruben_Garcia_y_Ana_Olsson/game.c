/**
 * @brief It implements the game structure
 *
 * @file game.c
 * @author Profesores Pprog, Rubén, Ana
 * @version 2
 * @date 09-03-2025
 */

#include "game.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "character.h"
#include "command.h"
#include "game_reader.h"
#include "object.h"
#include "player.h"
#include "space.h"

/**
 Private structure
*/
struct _Game {
  Space *spaces[MAX_SPACES];
  Player *player;
  Object *objects[MAX_OBJECTS];
  Character *characters[MAX_CHARACTERS];
  int n_spaces;
  int n_objects;
  int n_characters;
  Command *last_cmd;
  char message[WORD_SIZE];
  Bool finished;
};

/*Create & destroy*/
Status game_create(Game *game) {
  int i;
  /*Space *inventory = NULL;*/

  if (game == NULL) {
    return ERROR;
  }

  /*  Crear el jugador */
  game->player = player_create(PLAYER_ID);
  if (game->player == NULL) {
    free(game);
    return ERROR;
  }

  /*  Inicializar espacios y objetos en NULL */
  for (i = 0; i < MAX_SPACES; i++) {
    game->spaces[i] = NULL;
  }

  for (i = 0; i < MAX_OBJECTS; i++) {
    game->objects[i] = NULL;
  }

  game->n_spaces = 0;
  game->n_objects = 0;

  strcpy(game->message, "");

  /*  Establecer la ubicación inicial del jugador */
  player_set_location(game->player, NO_ID);

  /*  Crear el comando de último movimiento */
  game->last_cmd = command_create();
  if (game->last_cmd == NULL) {
    player_destroy(game->player);
    free(game);
    return ERROR;
  }

  game->finished = FALSE;
  return OK;
}

Status game_destroy(Game *game) {
  int i;
  if (!game) {
    return ERROR;
  }

  /*  Liberar los espacios */
  for (i = 0; i < game->n_spaces; i++) {
    space_destroy(game->spaces[i]);
    /*  Asegurar que space_destroy libera correctamente */
    game->spaces[i] = NULL;
  }

  /*  Liberar los objetos */
  for (i = 0; i < game->n_objects; i++) {
    object_destroy(game->objects[i]);
    /*  Asegurar que object_destroy libera correctamente */
    game->objects[i] = NULL;
  }

  /*  Liberar los personajes */
  for (i = 0; i < MAX_CHARACTERS; i++) { /*  Usamos MAX_CHARACTERS ya que la estructura lo define así */
    if (game->characters[i]) {
      character_destroy(game->characters[i]); /*  Liberar memoria de cada personaje */
      game->characters[i] = NULL;
    }
  }

  /*  Liberar el jugador */
  player_destroy(game->player);
  game->player = NULL;

  /*  Liberar el último comando */
  if (game->last_cmd) {
    command_destroy(game->last_cmd);
    game->last_cmd = NULL;
  }

  /*  Liberar la memoria de game */
  free(game);
  game = NULL;

  return OK;
}

Status game_initialize(Game *game) {
  if (!game) {
    return ERROR;
  }
  /*  Lógica de inicialización */
  return OK;
}

Game *game_init() {
  Game *game = (Game *)calloc(1, sizeof(Game));
  if (!game) {
    return NULL;
  }
  return game;
}

/*Manejo de spaces*/
Space **game_get_spaces(Game *game) {
  if (!game) {
    return NULL;
  }
  return game->spaces;
}

Space *game_get_space(Game *game, Id id) {
  int i;
  if (!game || id == NO_ID) return NULL;

  for (i = 0; i < game->n_spaces; i++) {
    if (id == space_get_id(game->spaces[i])) {
      return game->spaces[i];
    }
  }
  return NULL;
}

/**
 * @brief
 * @author
 *
 * @param space a pointer to the space
 * @return
 */
Status space_get_n_object_name(Game *game, Id space_id, int n, char *name) {
  if (!game || space_id == NO_ID) {
    return NO_ID;
  }

  strcpy(name, object_get_name(game_get_object_from_id(game, space_get_n_object(game_get_space(game, space_id), n))));
  if (!name) {
    return ERROR;
  }

  return OK;
}

Id game_get_space_id_at(Game *game, int position) {
  Space **spaces = game_get_spaces(game);

  if (!game || position < 0 || position >= game_get_num_spaces(game)) {
    printf("Error: Invalid game or position\n");
    return NO_ID;
  }

  if (!spaces) {
    printf("Error: Could not get spaces from game\n");
    return NO_ID;
  }

  return space_get_id(spaces[position]);
}

/*Manejo de player*/
Player *game_get_player(Game *game) {
  if (!game) {
    return NULL;
  }
  return game->player;
}

Id game_get_player_location(Game *game) {
  if (!game || !game->player) return NO_ID;
  return player_get_location(game->player);
}

Status game_set_player_location(Game *game, Id id) {
  if (!game || !game->player || id == NO_ID) return ERROR;
  return player_set_location(game->player, id);
}

/*Manejo de objects*/
Object **game_get_objects(Game *game) {
  if (!game) {
    return NULL;
  }
  return game->objects;
}

Id game_get_object_location(Game *game, Id object_id) {
  int i = 0;

  if (!game) {
    return NO_ID;
  }

  /*Si no está en los espacios, miramos si lo tiene el jugador*/
  if (player_has_object(game_get_player(game), object_id) == TRUE) {
    return player_get_id(game->player);
  }

  for (i = 0; i < game_get_num_spaces(game); i++) {
    if (space_has_object(game->spaces[i], object_id) == TRUE) {
      return space_get_id(game->spaces[i]);
    }
  }

  return NO_ID;
}

Status game_set_object_location(Game *game, Id location, Id object_id) {
  Id current_location;

  if (!game || location == NO_ID || object_id == NO_ID) {
    return ERROR;
  }

  current_location = game_get_object_location(game, object_id);
  printf("The desired object's location is %li\n", current_location); /*DEBUG*/

  /*El objeto pasará de estar en current_location a location, hay dos casos, player->space, space->player*/

  if (current_location == PLAYER_ID) {
    /*Caso player->space*/
    /*Le quitamos el objeto al player*/
    if (player_remove_object(game_get_player(game), object_id) == ERROR) {
      return ERROR;
    }

    /*Le damos el objeto al space*/
    if (space_set_object(game_get_space(game, game_get_player_location(game)), object_id) == ERROR) {
      return ERROR;
    }

    return OK;

  } else {
    /*Caso space->player*/
    /*Le quitamos el objeto al space*/
    if (space_remove_object(game_get_space(game, current_location), object_id) == ERROR) {
      return ERROR;
    }
    /*Le damos el objeto al player*/
    if (player_add_object(game_get_player(game), object_id) == ERROR) {
      return ERROR;
    }

    return OK;
  }

  return OK;
}

Object *game_get_object_from_id(Game *game, Id object_id) {
  int i;

  if (!game) {
    return NULL;
  }

  for (i = 0; i < game->n_objects; i++) {
    if (game->objects[i] && object_get_id(game->objects[i]) == object_id) {
      return game->objects[i];
    }
  }

  return NULL;
}

Object *game_get_n_object(Game *game, int n) {
  if (!game) {
    return NULL;
  }

  return game->objects[n];
}

Id game_get_object_id_from_name(Game *game, char *object_name) {
  int i;

  if (!game || !object_name) {
    return NO_ID;
  }

  for (i = 0; i < game_get_num_objects(game); i++) {
    if (strcmp(object_get_name(game->objects[i]), object_name) == 0) {
      return object_get_id(game->objects[i]);
    }
  }

  return NO_ID;
}

Status game_get_string_of_objects_in_space(Game *game, Id space_id, char *objs) {
  char temp_obj[BOX_WIDTH + 1];
  int i = 0;
  int n_objects_printed = 0;

  if (!game) {
    return ERROR;
  }

  for (i = 0; i < space_get_num_objects(game_get_space(game, space_id)); i++) {
    space_get_n_object_name(game, space_id, i, temp_obj);
    if (strlen(objs) + strlen(temp_obj) > BOX_WIDTH + 1 - 3) {
      if (strlen(objs) > BOX_WIDTH + 1 - 3) {
        strtok(objs, " ");
      }
      if (objs[strlen(objs - 2)] != '.') {
        strcat(objs, "...");
      }
    } else {
      strcat(objs, temp_obj);
      n_objects_printed++;
      if (n_objects_printed != space_get_num_objects(game_get_space(game, space_id))) {
        strcat(objs, ", ");
      }
    }
  }

  while (strlen(objs) < BOX_WIDTH - 1) {
    strcat(objs, " ");
  }

  return OK;
}

/*Manejo de characters*/
Character **game_get_characters(Game *game) {
  if (!game) {
    return NULL;
  }
  return game->characters;
}

Character *game_get_character(Game *game, Id character_id) {
  int i;

  if (!game || character_id == NO_ID) {
    return NULL;
  }

  for (i = 0; i < MAX_CHARACTERS; i++) {
    if (game->characters[i] && character_get_id(game->characters[i]) == character_id) {
      return game->characters[i];
    }
  }

  return NULL;
}

Id game_get_character_location(Game *game, Id character_id) {
  int i = 0;

  if (!game) {
    return NO_ID;
  }

  for (i = 0; i < game_get_num_spaces(game); i++) {
    if (space_has_character(game->spaces[i], character_id) == TRUE) {
      return space_get_id(game->spaces[i]);
    }
  }

  return NO_ID;
}

Status game_set_character_location(Game *game, Id location, Id character_id) {
  Id current_location;

  if (!game || location == NO_ID || character_id == NO_ID) {
    return ERROR;
  }

  current_location = game_get_character_location(game, character_id);
  printf("The desired character's location is %li\n", current_location); /*DEBUG*/

  /*Le damos el objeto al space*/
  if (space_set_character(game_get_space(game, game_get_player_location(game)), character_id) == ERROR) {
    return ERROR;
  }

  /*if (space_remove_character(game_get_space(game, current_location), character_id) == ERROR) {
    return ERROR;
  }*/

  return OK;
}

Id game_get_character_id_from_name(Game *game, char *name) {
  int i;

  if (!game || !name) {
    return NO_ID;
  }

  for (i = 0; i < MAX_CHARACTERS; i++) {
    if (game->characters[i] && strcmp(character_get_name(game->characters[i]), name) == 0) {
      return character_get_id(game->characters[i]);
    }
  }

  return NO_ID;
}

Character *game_get_n_character(Game *game, int n) {
  if (!game) {
    return NULL;
  }

  return game->characters[n];
}

char *game_get_character_desc_at_space(Game *game, Id space_id) {
  if (!game || space_id == NO_ID) {
    return NULL;
  }

  return character_get_description(game_get_character(game, space_get_character(game_get_space(game, space_id))));
}

/*Manejo de n_objects*/
int game_get_num_objects(Game *game) {
  if (!game) {
    return -1;
  }
  return game->n_objects;
}

void game_increment_num_objects(Game *game) {
  if (game) {
    game->n_objects++;
  }
}

/*Manejo de n_spaces*/
int game_get_num_spaces(Game *game) {
  if (!game) {
    return -1;
  }
  return game->n_spaces;
}

void game_increment_num_spaces(Game *game) {
  if (game) {
    game->n_spaces++;
  }
}

/*Manejo de n_characters*/
int game_get_num_characters(Game *game) {
  if (!game) {
    return -1;
  }
  return game->n_characters;
}

void game_increment_num_characters(Game *game) {
  if (game) {
    game->n_characters++;
  }
}

/*Manejo de last_cmd*/
Command *game_get_last_command(Game *game) {
  if (!game) return NULL;
  return game->last_cmd;
}

Status game_set_last_command(Game *game, Command *command) {
  if (!game) return ERROR;
  game->last_cmd = command;
  return OK;
}

/*Manejo de message*/
char *game_get_message(Game *game) {
  if (!game) {
    return NULL;
  }

  return game->message;
}

Status game_set_message(Game *game, char *message) {
  if (!game) {
    return ERROR;
  }

  strcpy(game->message, message);

  return OK;
}

/*Manejo de finished*/
Bool game_get_finished(Game *game) {
  if (!game) return FALSE;
  return game->finished;
}

Status game_set_finished(Game *game, Bool finished) {
  if (!game) {
    return ERROR;
  }
  game->finished = finished;
  return OK;
}

/*Print*/
void game_print(Game *game) {
  int i;
  if (!game) return;

  printf("\n\n-------------\n\n");
  printf("=> Spaces: \n");
  for (i = 0; i < game->n_spaces; i++) {
    space_print(game->spaces[i]);
  }

  for (i = 0; i < MAX_OBJECTS; i++) {
    if (object_get_id(game->objects[i]) != NO_ID) {
      printf("=> %s location: %d\n", object_get_name(game->objects[i]), (int)game_get_object_location(game, object_get_id(game->objects[i])));
    }
  }

  printf("=> Player location: %d\n", (int)game_get_player_location(game));
}

/*Adds*/
Status game_add_space(Game *game, Space *space) {
  Space **spaces = game_get_spaces(game);

  if (!game || !space || game_get_num_spaces(game) >= MAX_SPACES) {
    printf("Error: Invalid game or space, or maximum spaces reached\n");
    return ERROR;
  }

  if (!spaces) {
    printf("Error: Could not get spaces from game\n");
    return ERROR;
  }

  spaces[game_get_num_spaces(game)] = space;
  game_increment_num_spaces(game);
  printf("Space added successfully\n");

  return OK;
}

Status game_add_object(Game *game, Object *object) {
  Object **objects = game_get_objects(game);

  if (!game || !object || game_get_num_objects(game) >= MAX_OBJECTS) {
    printf("Error: Invalid game or object, or maximum objects reached\n");
    return ERROR;
  }

  if (!objects) {
    printf("Error: Could not get objects from game\n");
    return ERROR;
  }

  objects[game_get_num_objects(game)] = object;
  game_increment_num_objects(game);
  printf("Object added successfully\n");

  return OK;
}

Status game_add_character(Game *game, Character *character) {
  Character **characters = game_get_characters(game);

  if (!game || !character || game_get_num_characters(game) >= MAX_OBJECTS) {
    printf("Error: Invalid game or character, or maximum characters reached\n");
    return ERROR;
  }

  if (!characters) {
    printf("Error: Could not get characters from game\n");
    return ERROR;
  }

  characters[game_get_num_characters(game)] = character;
  game_increment_num_characters(game);
  printf("Chracter added successfully\n");

  return OK;
}